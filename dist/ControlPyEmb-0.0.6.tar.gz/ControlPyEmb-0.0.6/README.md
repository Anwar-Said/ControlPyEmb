# ControlPyEmb
This library provides implementations for control-based graph embedding methods and benchmarks
